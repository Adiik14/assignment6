package kz.aitu.oop.assignment6;

public class vCofeeTable implements IcofeeTable {
    @Override
    public void color() {
        System.out.println("black");
    }

    @Override
    public void legs() {
        System.out.println("4");
    }
}
