package kz.aitu.oop.assignment6;

public interface IcofeeTable {
    public void color();
    public void legs();
}
