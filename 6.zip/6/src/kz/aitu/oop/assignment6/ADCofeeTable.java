package kz.aitu.oop.assignment6;

public class ADCofeeTable implements IcofeeTable {
    @Override
    public void color() {
        System.out.println("white");
    }

    @Override
    public void legs() {
        System.out.println("4");
    }
}