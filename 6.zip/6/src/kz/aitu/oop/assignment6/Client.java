package kz.aitu.oop.assignment6;

public class Client {
    public static void main (String[] args) {
        FabstractF FurAbsFact = new ADff();
        Ichair ArtChair = FurAbsFact.createChair();
        Isofa ArtSofa = FurAbsFact.createSofa();
        IcofeeTable ArtCoffeeTable = FurAbsFact.createCoffeeTable();

        ArtChair.color();
        ArtChair.legs();

        ArtSofa.color();
        ArtSofa.legs();

        ArtCoffeeTable.color();
        ArtCoffeeTable.legs();
    }
}