package kz.aitu.oop.assignment6;

public class vSofa implements Isofa {
    @Override
    public void color() {
        System.out.println("red");
    }

    @Override
    public void legs() {
        System.out.println("4");
    }
}