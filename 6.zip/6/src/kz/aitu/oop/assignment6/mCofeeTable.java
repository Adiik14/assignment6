package kz.aitu.oop.assignment6;

public class mCofeeTable implements IcofeeTable {
    @Override
    public void color() {
        System.out.println("yellow");
    }

    @Override
    public void legs() {
        System.out.println("3");
    }
}
