package kz.aitu.oop.assignment6;

public class ADchair implements Ichair{
    @Override
    public void color() {
        System.out.println("blue");
    }

    @Override
    public void legs() {
        System.out.println("4");
    }
}
