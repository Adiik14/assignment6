package kz.aitu.oop.assignment6;

public class ADsofa implements Isofa{
    @Override
    public void color() {
        System.out.println("orange");
    }

    @Override
    public void legs() {
        System.out.println("6");
    }
}
