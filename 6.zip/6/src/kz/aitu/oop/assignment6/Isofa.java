package kz.aitu.oop.assignment6;

public interface Isofa {
    public void color();
    public void legs();
}
