package kz.aitu.oop.assignment6;

public class mChair implements Ichair {
    @Override
    public void color() {
        System.out.println("brown");
    }

    @Override
    public void legs() {
        System.out.println("3");
    }
}
