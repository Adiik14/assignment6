package kz.aitu.oop.assignment6;

public class ADff implements FabstractF{
    @Override
    public Ichair createChair() {
        return new ADchair();
    }

    @Override
    public Isofa createSofa() {
        return new ADsofa();
    }

    @Override
    public IcofeeTable createCoffeeTable() {
        return new ADCofeeTable();
    }
}
