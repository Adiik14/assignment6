package kz.aitu.oop.assignment6;

public class mFF implements FabstractF{
    @Override
    public Ichair createChair() {
        return new mChair();
    }

    @Override
    public Isofa createSofa() {
        return new mSofa();
    }

    @Override
    public IcofeeTable createCoffeeTable() {
        return new mCofeeTable();
    }
}
