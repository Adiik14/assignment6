package kz.aitu.oop.assignment6;

public interface FabstractF {
    public Ichair createChair();
    public Isofa createSofa();
    public IcofeeTable createCoffeeTable();
}
