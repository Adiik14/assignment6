package kz.aitu.oop.assignment6;

public class mSofa implements Isofa {
    @Override
    public void color() {
        System.out.println("purple");
    }

    @Override
    public void legs() {
        System.out.println("4");
    }
}
