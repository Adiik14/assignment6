package kz.aitu.oop.assignment6;

public class vChair implements Ichair {
    @Override
    public void color() {
        System.out.println("green");
    }

    @Override
    public void legs() {
        System.out.println("5");
    }
}
