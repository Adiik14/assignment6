package kz.aitu.oop.assignment6;

public interface Ichair {
    public void color();
    public void legs();
}