package kz.aitu.oop.assignment6;

public class vFF implements FabstractF{
    public Ichair createChair() { return new vChair(); }
    public Isofa createSofa() {
        return new vSofa();
    }
    public IcofeeTable createCoffeeTable() {
        return new vCofeeTable();
    }
}